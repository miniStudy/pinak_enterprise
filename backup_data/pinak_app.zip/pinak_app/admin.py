from django.contrib import admin
from pinak_app.models import *

# Register your models here.
admin.site.register(Company_Details)
admin.site.register(Bank_Details)
admin.site.register(Machine_Types)
admin.site.register(Machines)
admin.site.register(Machine_Maintenance)
admin.site.register(Maintenance_Types)
admin.site.register(Documents)
admin.site.register(Document_Types)
admin.site.register(language)
admin.site.register(Settingsss)
admin.site.register(Bill)
admin.site.register(Material_Owner_data)
admin.site.register(Project_Person_Data)
admin.site.register(Material)
admin.site.register(User)
admin.site.register(Person)

